# BingX VST (testnet) ccxt quirks & workarounds

Condensed from a live trading session. The testnet (`USE_TESTNET=true`,
`BINGX_TESTNET_API_KEY/SECRET`, `set_sandbox_mode(True)`, symbol `XRP/USDT:USDT`)
behaves differently from docs — capture the fixes, don't re-discover them.

## 1. No realized PnL from the exchange (compute it yourself)
`fetch_my_trades` returns objects whose `info` has
`filledTm, volume, price, amount, commission, positionSide, ...` but **no
realizedPnl / realisedPnl field**. `fetchLedger(...)` raises
`bingx fetchLedger() is not supported yet`.

So: read the leg's `entryPrice` via `fetch_positions` BEFORE closing, get mark
from `fetch_order_book`, and compute realized PnL yourself. Persist to a journal
(`runtime/trade_journal.jsonl`) — never trust the exchange field.

```python
# in tools/qe_trade.py market(), before create_order:
await ex.load_markets()
ps = await ex.fetch_positions(symbols=[CCXT_SYMBOL])
entry = None
for p in ps:
    if str(p.get("side","")).upper() == pos_side.upper() and float(p.get("contracts") or 0)!=0:
        entry = float(p.get("entryPrice") or 0)
ob = await ex.fetch_order_book(CCXT_SYMBOL, limit=5)
bids, asks = ob.get("bids",[]), ob.get("asks",[])
mark = (bids[0][0]+asks[0][0])/2 if bids and asks else None
# after create_order:
if pos_side.upper()=="LONG":
    realized = round((mark-entry)*float(qty), 4)
else:  # SHORT closed by buying
    realized = round((entry-mark)*float(qty), 4)
```

Then `trades <hours>` reads the journal (not the exchange) for realized PnL.

## 2. Error `code 101209` — max position value / notional cap
When adding to a leg, BingX returns:
`{"code":101209,"msg":"The maximum position value for this leverage is 1000 @ 1.1141"}`
at the current 10x leverage, the SHORT leg has hit its size limit (~890k XRP).
Implication: **you CANNOT add to SHORT — only reduce it** (buy-to-cover) when in
profit. Build the grid ASYMMETRIC: keep adding LONG on dips (TP +0.2%), only
HARVEST the SHORT in profit. Don't retry SHORT adds; they will keep failing.

## 3. `qe_trade.py` command reference (agent's preferred interface)
Run from `/home/layman/QuantumEdge` with `.venv/bin/python3`.
- `tools/qe_trade.py snapshot` → price, book (±20 + wall clusters + imbalance),
  balance, legs, open_orders, **session** (ASIA/EU/US by UTC hour).
- `tools/qe_trade.py place <buy|sell> <LONG|SHORT> <qty> <price> [tp]`
- `tools/qe_trade.py market <buy|sell> <LONG|SHORT> <qty>`  (self-computes PnL)
- `tools/qe_trade.py cancel_all` | `cancel <id>`
- `tools/qe_trade.py grid <lo> <hi> <n_side> <qty>` — n_side buy-limits below mid
  (TP+0.2%) + n_side sell-limits above (TP−0.2%) + 2 breakout orders each edge.
- `tools/qe_trade.py trades <hours>` — realized PnL from the journal.

## 4. Grid sizing / interruption
- Total notional ≈ open_orders × qty × price must fit `free` margin. At ~20k VST
  free, 15×15 × 2000 XRP is too big — prefer smaller; watch `open_orders_count`.
- An interrupted `grid` leaves a PARTIAL grid (some legs placed, some not).
  ALWAYS `snapshot` + inspect `open_orders` after any interruption before
  re-running; `cancel_all` then re-grid only if lopsided.
- Range = STACK WALLS: `bid_walls` floor / `ask_walls` ceiling. Place limits just
  IN FRONT of walls so they fill; each scalp entry gets TP ≈ ±0.2%.
