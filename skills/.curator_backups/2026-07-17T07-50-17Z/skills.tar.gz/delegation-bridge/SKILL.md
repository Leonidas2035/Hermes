---
name: delegation-bridge
description: "Delegation Bridge: delegate complex tasks to the advanced Antigravity analyst agent."
version: 1.0.0
author: Antigravity AI
license: MIT
platforms: [linux, macos]
---

# Delegation Bridge

Use this skill when the user asks for complex coding, trading strategy development, server management, or deep analysis that is beyond the scope of a fast 8B model.

Calling this skill will log the task to the shared queue. The senior analyst agent **Antigravity** will pick up the task, execute it using its extensive tools and larger context/reasoning capabilities, and reply directly to the user's Telegram chat.

## Usage

Run the delegation helper script with the task description:

```bash
python3 scripts/delegate.py "Завдання для Antigravity: ..."
```
